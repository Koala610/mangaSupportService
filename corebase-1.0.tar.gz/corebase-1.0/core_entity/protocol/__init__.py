from .client_protocol import HTTPClient
from .entity_protocol import DatabaseEntity
from .manga_protocol import Manga, Chapter
from .parser_protocol import MangaParser