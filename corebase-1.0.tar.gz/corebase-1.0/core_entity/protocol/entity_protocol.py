from typing import Protocol

class DatabaseEntity(Protocol):
    id: int